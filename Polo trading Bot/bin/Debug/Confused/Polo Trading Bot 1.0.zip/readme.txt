Poloniex Trading bot

1. Install the software then run it.
2. Go to poloniex.com, register, deposit funds and create api key and secret.
3. In poloniex bot software, login using email and password.
4. Click "Settings" button and fill the api key and secret from poloniex.com
5. Click "Main" button and fill all following fields
   
   Market Pairing = Any currency pair supported in poloniex format should like this "BTC_ETH" as sample.
   Number of Buy order = Only 3 and 5 is supported, means it will place 3 or 5 orders and sells.
   Range of buy order = amount btc you want to buy.
   Sell percentage = This is your profit percentage per sell.
   Max 24 hour BTC spend = this is the limit to spend your BTC in 24 hours, if reach this will stop.
   Cancel Buy Interval = this will cancel your buy order interval every minutes
6. When all setup hit "Start" button to start the software

Stop button will stop the software from trading, You can view logs button to what is happening in the trading.

If you have any question regarding this bot, please contact lttbesitulo@gmail.com.

Login Info:

Email : polo@gmail.com
Password : polotrading